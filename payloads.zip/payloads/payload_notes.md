putty.exe - shellter injected netcat payload
mtrp.jar - java meterpreter bind shell
cmd.aspx - asp.net webshell
mtrprev80.exe - meterpreter reverse shell
mtrprev80xor.exe - " but xor encoded
EmpireMac.doc - empire macro payload in a word doc
adinsight.exe - shellter injected custom meterpreter stager